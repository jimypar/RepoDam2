public class Temperatura {

    private String year;
    private String incremento;

    public Temperatura(String year, String incremento) {
        this.year = year;
        this.incremento = incremento;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getIncremento() {
        return incremento;
    }

    public void setIncremento(String incremento) {
        this.incremento = incremento;
    }
}
